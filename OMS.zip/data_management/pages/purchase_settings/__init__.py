"""Purchase settings submodules."""
