"""Data management module."""
