"""Analysis module package."""
